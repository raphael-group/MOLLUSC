python run_mollusc -c ../character_matrix.csv -t ../input_tree.nwk --delimiter comma -p ../mutation_priors.csv --nInitials 1 --randseeds 3103 -o mollusc_output.txt --timescale 215 -v
